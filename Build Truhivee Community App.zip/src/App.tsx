import { useEffect, useMemo, useState } from "react";

type Screen =
  | "splash"
  | "onboarding"
  | "welcome"
  | "signup"
  | "otp"
  | "login"
  | "forgot"
  | "resetSent"
  | "profileSetup"
  | "interests"
  | "location"
  | "home"
  | "discover"
  | "events"
  | "communities"
  | "eventDetail"
  | "communityDetail"
  | "registration"
  | "registrationQuestions"
  | "registered"
  | "create"
  | "eventApplication"
  | "eventApplicationReview"
  | "eventApplicationStatus"
  | "eventBasic"
  | "eventSchedule"
  | "eventLocation"
  | "eventTickets"
  | "eventQuestions"
  | "eventPreview"
  | "eventPublish"
  | "eventManagement"
  | "communityIntro"
  | "communityApplicant"
  | "communityConcept"
  | "communityExperience"
  | "communityReview"
  | "communitySubmitted"
  | "communityStatus"
  | "hive"
  | "communitySetup"
  | "communityPreview"
  | "communityPublish"
  | "communityManagement"
  | "discussions"
  | "profile"
  | "editProfile"
  | "settings"
  | "account"
  | "tickets"
  | "about"
  | "contact"
  | "deleteAccount"
  | "notifications"
  | "legal";

type IconName =
  | "home"
  | "search"
  | "plus"
  | "users"
  | "user"
  | "bell"
  | "arrow"
  | "back"
  | "calendar"
  | "pin"
  | "clock"
  | "heart"
  | "share"
  | "check"
  | "settings"
  | "ticket"
  | "message"
  | "edit"
  | "camera"
  | "chevron"
  | "filter"
  | "globe"
  | "lock"
  | "eye"
  | "more"
  | "spark"
  | "mail";

const photos = {
  friends:
    "https://images.unsplash.com/photo-1625283518288-00362afc8663?auto=format&fit=crop&w=900&q=85",
  gathering:
    "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=900&q=85",
  circle:
    "https://images.unsplash.com/photo-1702599057905-d3859caa8b61?auto=format&fit=crop&w=900&q=85",
  outdoors:
    "https://images.unsplash.com/photo-1498661694102-0a3793edbe74?auto=format&fit=crop&w=900&q=85",
  pottery:
    "https://images.unsplash.com/photo-1609881583302-61548332039c?auto=format&fit=crop&w=900&q=85",
  workshop:
    "https://images.unsplash.com/photo-1470487274665-5c67dce2beca?auto=format&fit=crop&w=900&q=85",
  music:
    "https://images.unsplash.com/photo-1770096732027-3c8adfcafd55?auto=format&fit=crop&w=900&q=85",
  festival:
    "https://images.unsplash.com/photo-1787233795090-d0605e9b9c86?auto=format&fit=crop&w=900&q=85",
  books:
    "https://images.unsplash.com/photo-1754373383600-a8bd96c2614b?auto=format&fit=crop&w=900&q=85",
};

const eventData = [
  {
    title: "Clay & Conversations",
    meta: "Sat, 24 May · 4:00 PM",
    place: "The Studio, Indiranagar",
    price: "₹850",
    image: photos.pottery,
  },
  {
    title: "Sunset Social Run",
    meta: "Sun, 25 May · 5:30 PM",
    place: "Cubbon Park",
    price: "Free",
    image: photos.outdoors,
  },
  {
    title: "Indie Under the Stars",
    meta: "Fri, 30 May · 7:00 PM",
    place: "Courtyard Live",
    price: "₹499",
    image: photos.festival,
  },
  {
    title: "Creative Sunday Club",
    meta: "Sun, 1 Jun · 11:00 AM",
    place: "The Green Room",
    price: "₹650",
    image: photos.workshop,
  },
];

const communityData = [
  {
    title: "The Slow Sunday Club",
    genre: "Wellness · Bengaluru",
    members: "2.4k members",
    image: photos.friends,
    desc: "Unhurried mornings, mindful plans and good company.",
  },
  {
    title: "Make Something",
    genre: "Art & Creativity",
    members: "1.8k members",
    image: photos.pottery,
    desc: "A friendly corner for curious hands and creative minds.",
  },
  {
    title: "City Sound Society",
    genre: "Music · Bengaluru",
    members: "3.1k members",
    image: photos.music,
    desc: "Gigs, listening circles and new sounds every week.",
  },
];

const interests = [
  "Music",
  "Art",
  "Fitness",
  "Sports",
  "Travel",
  "Photography",
  "Reading",
  "Food",
  "Dance",
  "Technology",
  "Entrepreneurship",
  "Wellness",
  "Gaming",
  "Outdoor activities",
];
const categoryImages = [
  photos.music,
  photos.pottery,
  photos.outdoors,
  photos.circle,
  photos.friends,
  photos.workshop,
  photos.books,
  photos.gathering,
];

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: (
      <>
        <path d="m3 10 9-7 9 7" />
        <path d="M5 9v11h14V9M9 20v-6h6v6" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    users: (
      <>
        <path d="M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 20v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
      </>
    ),
    arrow: (
      <>
        <path d="M5 12h14M14 7l5 5-5 5" />
      </>
    ),
    back: (
      <>
        <path d="m15 18-6-6 6-6" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 10h18" />
      </>
    ),
    pin: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    heart: (
      <>
        <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z" />
      </>
    ),
    share: (
      <>
        <circle cx="18" cy="5" r="3" />
        <circle cx="6" cy="12" r="3" />
        <circle cx="18" cy="19" r="3" />
        <path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1V21H9v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 3.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1-.4H2V9h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8 3.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1H14v.1a1.7 1.7 0 0 0 1.1 1.5 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 20.4 8c.14.4.36.75.6 1 .28.28.64.42 1 .42V14h-.1a1.7 1.7 0 0 0-1.5 1Z" />
      </>
    ),
    ticket: (
      <>
        <path d="M3 7a2 2 0 0 0 2-2h14a2 2 0 0 0 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 0-2 2H5a2 2 0 0 0-2-2v-3a2 2 0 0 0 0-4Z" />
        <path d="M13 5v14" />
      </>
    ),
    message: (
      <>
        <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" />
      </>
    ),
    edit: (
      <>
        <path d="M12 20h9" />
        <path d="M16.5 3.5a2 2 0 0 1 3 3L8 18l-4 1 1-4Z" />
      </>
    ),
    camera: (
      <>
        <path d="M14.5 4 16 7h3a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h3l1.5-3Z" />
        <circle cx="12" cy="13" r="3" />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    filter: (
      <>
        <path d="M4 6h16M7 12h10M10 18h4" />
      </>
    ),
    globe: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" />
      </>
    ),
    lock: (
      <>
        <rect x="5" y="10" width="14" height="11" rx="2" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      </>
    ),
    eye: (
      <>
        <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z" />
        <circle cx="12" cy="12" r="2.5" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
      </>
    ),
    spark: (
      <>
        <path d="m12 3 1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6Z" />
        <path d="m19 16 .8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8Z" />
      </>
    ),
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m3 7 9 6 9-6" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

function Logo({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <div className={`logo ${light ? "light" : ""}`}>
      <div className="logo-mark">
        <span />
        <span />
        <span />
      </div>
      {!compact && <strong>truhivee</strong>}
    </div>
  );
}

function Button({
  children,
  onClick,
  variant = "primary",
  icon,
  disabled = false,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  icon?: IconName;
  disabled?: boolean;
}) {
  return (
    <button className={`btn ${variant}`} onClick={onClick} disabled={disabled}>
      {children}
      {icon && <Icon name={icon} size={18} />}
    </button>
  );
}

function Header({
  title,
  onBack,
  action,
}: {
  title: string;
  onBack?: () => void;
  action?: React.ReactNode;
}) {
  return (
    <header className="topbar">
      {onBack ? (
        <button className="icon-btn" onClick={onBack}>
          <Icon name="back" />
        </button>
      ) : (
        <Logo compact />
      )}
      <strong>{title}</strong>
      <div className="top-action">{action}</div>
    </header>
  );
}

function Field({
  label,
  placeholder,
  type = "text",
  area = false,
  value,
  onChange,
}: {
  label: string;
  placeholder?: string;
  type?: string;
  area?: boolean;
  value?: string;
  onChange?: (v: string) => void;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      {area ? (
        <textarea
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
        />
      ) : (
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
        />
      )}
    </label>
  );
}

function SelectField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="field">
      <span>{label}</span>
      <div className="select-value">
        {children}
        <Icon name="chevron" size={17} />
      </div>
    </label>
  );
}

function Progress({ step, total }: { step: number; total: number }) {
  return (
    <div className="progress-wrap">
      <div className="progress-label">
        <span>
          Step {step} of {total}
        </span>
        <span>{Math.round((step / total) * 100)}%</span>
      </div>
      <div className="progress">
        <i style={{ width: `${(step / total) * 100}%` }} />
      </div>
    </div>
  );
}

function ScreenShell({
  children,
  nav = false,
  className = "",
}: {
  children: React.ReactNode;
  nav?: boolean;
  className?: string;
}) {
  return <main className={`screen ${nav ? "with-nav" : ""} ${className}`}>{children}</main>;
}

function BottomNav({ current, go }: { current: Screen; go: (s: Screen) => void }) {
  const items: { label: string; icon: IconName; screen: Screen }[] = [
    { label: "Home", icon: "home", screen: "home" },
    { label: "Discover", icon: "search", screen: "discover" },
    { label: "Create", icon: "plus", screen: "create" },
    { label: "Hive", icon: "users", screen: "hive" },
    { label: "Profile", icon: "user", screen: "profile" },
  ];
  return (
    <nav className="bottom-nav">
      {items.map((item, i) => (
        <button
          key={item.label}
          className={`${current === item.screen ? "active" : ""} ${i === 2 ? "create-nav" : ""}`}
          onClick={() => go(item.screen)}
        >
          <span>
            <Icon name={item.icon} size={i === 2 ? 25 : 21} />
          </span>
          <small>{item.label}</small>
        </button>
      ))}
    </nav>
  );
}

function EventCard({
  event,
  onClick,
  wide = false,
}: {
  event: (typeof eventData)[number];
  onClick: () => void;
  wide?: boolean;
}) {
  return (
    <button className={`event-card ${wide ? "wide" : ""}`} onClick={onClick}>
      <div className="card-image">
        <img src={event.image} alt="" />
        <span className="save">
          <Icon name="heart" size={17} />
        </span>
        <b>{event.price}</b>
      </div>
      <div className="card-copy">
        <small>{event.meta}</small>
        <h3>{event.title}</h3>
        <p>
          <Icon name="pin" size={14} />
          {event.place}
        </p>
      </div>
    </button>
  );
}

function CommunityCard({
  item,
  joined,
  onJoin,
  onOpen,
}: {
  item: (typeof communityData)[number];
  joined?: boolean;
  onJoin?: () => void;
  onOpen: () => void;
}) {
  return (
    <article className="community-card" onClick={onOpen}>
      <img src={item.image} alt="" />
      <div>
        <small>{item.genre}</small>
        <h3>{item.title}</h3>
        <p>{item.desc}</p>
        <footer>
          <span>
            <Icon name="users" size={14} /> {item.members}
          </span>
          {onJoin && (
            <button
              className={joined ? "joined" : ""}
              onClick={(e) => {
                e.stopPropagation();
                onJoin();
              }}
            >
              {joined ? "Joined" : "Join"}
            </button>
          )}
        </footer>
      </div>
    </article>
  );
}

function SectionTitle({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <div className="section-title">
      <h2>{children}</h2>
      {onClick && (
        <button onClick={onClick}>
          See all <Icon name="arrow" size={15} />
        </button>
      )}
    </div>
  );
}

function FormScreen({
  title,
  subtitle,
  step,
  total,
  fields,
  next,
  back,
  nextLabel = "Continue",
  children,
}: {
  title: string;
  subtitle?: string;
  step?: number;
  total?: number;
  fields?: { label: string; placeholder?: string; area?: boolean; type?: string }[];
  next: () => void;
  back: () => void;
  nextLabel?: string;
  children?: React.ReactNode;
}) {
  return (
    <ScreenShell>
      <Header title="" onBack={back} />
      {step && total && <Progress step={step} total={total} />}
      <div className="page form-page">
        <span className="eyebrow">
          {step ? `STEP ${String(step).padStart(2, "0")}` : "TRUHIVEE"}
        </span>
        <h1>{title}</h1>
        {subtitle && <p className="lead">{subtitle}</p>}
        <div className="fields">
          {fields?.map((f, i) => (
            <Field key={i} {...f} />
          ))}
          {children}
        </div>
        <div className="sticky-action">
          <Button onClick={next} icon="arrow">
            {nextLabel}
          </Button>
        </div>
      </div>
    </ScreenShell>
  );
}

function ReviewBlock({
  title,
  rows,
  edit,
}: {
  title: string;
  rows: [string, string][];
  edit?: () => void;
}) {
  return (
    <section className="review-block">
      <header>
        <h3>{title}</h3>
        {edit && (
          <button onClick={edit}>
            <Icon name="edit" size={16} /> Edit
          </button>
        )}
      </header>
      {rows.map(([k, v]) => (
        <div className="review-row" key={k}>
          <span>{k}</span>
          <b>{v}</b>
        </div>
      ))}
    </section>
  );
}

function StatusView({
  type,
  subject,
  next,
  back,
  setType,
}: {
  type: "pending" | "approved" | "rejected";
  subject: "event" | "community";
  next: () => void;
  back: () => void;
  setType?: (type: "pending" | "approved" | "rejected") => void;
}) {
  const content = {
    pending: [
      "Application under review",
      "Our team is taking a thoughtful look at your application. You’ll hear from us within 3–5 working days.",
      "Review in progress",
    ],
    approved: [
      "You’re approved to host",
      subject === "community"
        ? "Your community space is ready in Hive. Complete the setup and invite your first members."
        : "You can now shape and publish your first Truhivee experience.",
      subject === "community" ? "Go to Hive" : "Create your event",
    ],
    rejected: [
      "Not quite yet",
      "We’re unable to approve this application right now. We’ve shared feedback to help you strengthen a future submission.",
      "Review feedback",
    ],
  }[type];
  return (
    <ScreenShell className="status-screen">
      <Header title="Application status" onBack={back} />
      <div className="status-body">
        <div className={`status-orb ${type}`}>
          <Icon
            name={type === "approved" ? "check" : type === "pending" ? "clock" : "message"}
            size={34}
          />
        </div>
        <span className={`status-pill ${type}`}>{type}</span>
        <h1>{content[0]}</h1>
        <p>{content[1]}</p>
        <div className="status-timeline">
          <i />
          <div>
            <b>Application submitted</b>
            <small>Today, 10:24 AM</small>
          </div>
        </div>
        <div className="status-timeline muted">
          <i />
          <div>
            <b>{type === "pending" ? "Team review" : "Decision shared"}</b>
            <small>{type === "pending" ? "Usually 3–5 working days" : "Completed"}</small>
          </div>
        </div>
        <Button onClick={next}>{content[2]}</Button>
        {setType && (
          <div className="state-preview">
            <small>PROTOTYPE STATUS STATES</small>
            <div>
              {(["pending", "approved", "rejected"] as const).map((status) => (
                <button
                  className={type === status ? "active" : ""}
                  key={status}
                  onClick={() => setType(status)}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </ScreenShell>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [history, setHistory] = useState<Screen[]>([]);
  const [onboard, setOnboard] = useState(0);
  const [joined, setJoined] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    "Art",
    "Music",
    "Wellness",
  ]);
  const [hostApproved, setHostApproved] = useState(false);
  const [communityApproved, setCommunityApproved] = useState(false);
  const [eventStatus, setEventStatus] = useState<"pending" | "approved" | "rejected">("pending");
  const [communityStatus, setCommunityStatus] = useState<"pending" | "approved" | "rejected">(
    "pending",
  );
  const [communityPublished, setCommunityPublished] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [hiveTab, setHiveTab] = useState<"created" | "joined">("created");
  const [ticketTab, setTicketTab] = useState<"upcoming" | "past">("upcoming");
  const [toast, setToast] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [authError, setAuthError] = useState(false);
  const [createdPost, setCreatedPost] = useState(false);
  const [showLogout, setShowLogout] = useState(false);

  const go = (next: Screen) => {
    setHistory((h) => [...h, screen]);
    setScreen(next);
    window.setTimeout(() => window.scrollTo(0, 0), 10);
  };
  const back = () => {
    const prev = history[history.length - 1];
    if (prev) {
      setHistory((h) => h.slice(0, -1));
      setScreen(prev);
    } else setScreen("home");
  };
  const notify = (text: string) => {
    setToast(text);
    window.setTimeout(() => setToast(""), 2200);
  };

  useEffect(() => {
    if (screen !== "splash") return;
    const timer = window.setTimeout(() => go("onboarding"), 2300);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen]);

  const onboardingSlides = [
    {
      title: "Find your kind of people.",
      text: "Discover communities built around the things you love.",
      image: photos.friends,
    },
    {
      title: "Make plans. Make memories.",
      text: "Find experiences, events and activities happening around you.",
      image: photos.festival,
    },
    {
      title: "Create something together.",
      text: "Build communities, bring people together and host experiences.",
      image: photos.workshop,
    },
  ];

  const isNav = ["home", "discover", "hive", "profile"].includes(screen);

  const content = useMemo(() => {
    switch (screen) {
      case "splash":
        return (
          <ScreenShell className="splash">
            <button className="splash-inner" onClick={() => go("onboarding")}>
              <Logo light />
              <div>
                <h1>
                  Find your people.
                  <br />
                  Find your place.
                </h1>
                <span>Community feels better together</span>
              </div>
              <div className="splash-loader">
                <i />
              </div>
            </button>
          </ScreenShell>
        );
      case "onboarding": {
        const slide = onboardingSlides[onboard];
        return (
          <ScreenShell className="onboarding">
            <div className="onboard-image" key={slide.image}>
              <img src={slide.image} alt="" />
              <div className="image-scrim" />
            </div>
            <button className="skip" onClick={() => go("welcome")}>
              Skip
            </button>
            <div className="onboard-card" key={slide.title}>
              <div className="pager">
                {onboardingSlides.map((_, i) => (
                  <i key={i} className={i === onboard ? "active" : ""} />
                ))}
              </div>
              <span className="eyebrow">WELCOME TO TRUHIVEE</span>
              <h1>{slide.title}</h1>
              <p>{slide.text}</p>
              <Button
                onClick={() => (onboard < 2 ? setOnboard(onboard + 1) : go("welcome"))}
                icon="arrow"
              >
                {onboard < 2 ? "Next" : "Get started"}
              </Button>
            </div>
          </ScreenShell>
        );
      }
      case "welcome":
        return (
          <ScreenShell className="auth welcome">
            <div className="auth-art">
              <img src={photos.circle} alt="" />
              <div className="brand-float">
                <Logo light />
              </div>
            </div>
            <div className="auth-panel">
              <span className="eyebrow">WELCOME</span>
              <h1>Your next connection starts here.</h1>
              <p>Discover people, places and plans that feel like you.</p>
              <Button onClick={() => go("signup")}>
                <Icon name="mail" size={19} /> Continue with email
              </Button>
              <Button variant="secondary" onClick={() => go("login")}>
                <span className="google">G</span> Continue with Google
              </Button>
              <button className="text-link" onClick={() => go("login")}>
                Already here? <b>Log in</b>
              </button>
              <small>
                By continuing, you agree to our <u>Terms</u> and <u>Privacy Policy</u>.
              </small>
            </div>
          </ScreenShell>
        );
      case "signup":
        return (
          <FormScreen
            title="Create your account"
            subtitle="A few details and your hive is ready."
            back={back}
            next={() => go("otp")}
            nextLabel="Create account"
            fields={[
              { label: "Full name", placeholder: "How should we know you?" },
              { label: "Email address", placeholder: "you@example.com", type: "email" },
              { label: "Password", placeholder: "At least 8 characters", type: "password" },
              { label: "Confirm password", placeholder: "Enter it once more", type: "password" },
            ]}
          >
            <label className="check-row">
              <input type="checkbox" defaultChecked />
              <i>
                <Icon name="check" size={13} />
              </i>
              <span>I agree to the Terms & Privacy Policy</span>
            </label>
            <div className="divider">
              <span>or</span>
            </div>
            <Button variant="secondary">
              <span className="google">G</span> Sign up with Google
            </Button>
          </FormScreen>
        );
      case "otp":
        return (
          <ScreenShell className="auth">
            <Header title="" onBack={back} />
            <div className="page otp-page">
              <div className="mail-orb">
                <Icon name="mail" size={28} />
              </div>
              <span className="eyebrow">CHECK YOUR INBOX</span>
              <h1>Verify your email</h1>
              <p className="lead">
                We sent a six-digit code to <b>maya@example.com</b>
              </p>
              <div className={`otp ${authError ? "error" : ""}`}>
                {otp.map((n, i) => (
                  <input
                    key={i}
                    maxLength={1}
                    inputMode="numeric"
                    value={n}
                    onChange={(e) => {
                      const next = [...otp];
                      next[i] = e.target.value;
                      setOtp(next);
                      setAuthError(false);
                    }}
                  />
                ))}
              </div>
              {authError && <p className="error-text">That code doesn’t look right. Try 246810.</p>}
              <button className="text-link">
                Didn’t receive it? <b>Resend code</b>
              </button>
              <Button
                onClick={() =>
                  otp.join("") === "246810" || otp.join("").length === 0
                    ? go("profileSetup")
                    : setAuthError(true)
                }
              >
                Verify email
              </Button>
              <small className="hint">Prototype tip: leave blank or use 246810</small>
            </div>
          </ScreenShell>
        );
      case "login":
        return (
          <FormScreen
            title="Welcome back"
            subtitle="Your people have been waiting."
            back={back}
            next={() => go("home")}
            nextLabel="Log in"
            fields={[
              { label: "Email address", placeholder: "you@example.com", type: "email" },
              { label: "Password", placeholder: "Your password", type: "password" },
            ]}
          >
            <button className="forgot-link" onClick={() => go("forgot")}>
              Forgot password?
            </button>
            <Button variant="secondary">
              <span className="google">G</span> Log in with Google
            </Button>
            <button className="text-link" onClick={() => go("signup")}>
              New here? <b>Create an account</b>
            </button>
          </FormScreen>
        );
      case "forgot":
        return (
          <FormScreen
            title="Reset your password"
            subtitle="Enter your email and we’ll send you a secure reset link."
            back={back}
            next={() => go("resetSent")}
            nextLabel="Send reset link"
            fields={[{ label: "Email address", placeholder: "you@example.com", type: "email" }]}
          />
        );
      case "resetSent":
        return (
          <ScreenShell className="status-screen">
            <Header title="" onBack={back} />
            <div className="status-body">
              <div className="status-orb approved">
                <Icon name="mail" size={32} />
              </div>
              <h1>Check your email</h1>
              <p>A reset link is on its way. It will expire in 30 minutes.</p>
              <Button onClick={() => go("login")}>Back to login</Button>
            </div>
          </ScreenShell>
        );
      case "profileSetup":
        return (
          <FormScreen
            title="Make it yours"
            subtitle="Help your future people recognise you."
            step={1}
            total={3}
            back={back}
            next={() => go("interests")}
            fields={[
              { label: "Display name", placeholder: "Maya" },
              { label: "Short bio", placeholder: "What makes you, you?", area: true },
              { label: "City", placeholder: "Bengaluru" },
            ]}
          >
            <button className="avatar-upload">
              <img src={photos.friends} alt="" />
              <span>
                <Icon name="camera" />
                Add a profile photo<small>JPG or PNG · Max 5MB</small>
              </span>
            </button>
          </FormScreen>
        );
      case "interests":
        return (
          <ScreenShell>
            <Header title="" onBack={back} />
            <Progress step={2} total={3} />
            <div className="page">
              <span className="eyebrow">PICK AT LEAST THREE</span>
              <h1>What lights you up?</h1>
              <p className="lead">We’ll use these to shape your recommendations.</p>
              <div className="interest-grid">
                {interests.map((item, i) => (
                  <button
                    key={item}
                    className={selectedInterests.includes(item) ? "selected" : ""}
                    onClick={() =>
                      setSelectedInterests((s) =>
                        s.includes(item) ? s.filter((x) => x !== item) : [...s, item],
                      )
                    }
                  >
                    <img src={categoryImages[i % categoryImages.length]} alt="" />
                    <span>{item}</span>
                    {selectedInterests.includes(item) && (
                      <i>
                        <Icon name="check" size={13} />
                      </i>
                    )}
                  </button>
                ))}
              </div>
              <div className="sticky-action">
                <Button disabled={selectedInterests.length < 3} onClick={() => go("location")}>
                  Continue · {selectedInterests.length} selected
                </Button>
              </div>
            </div>
          </ScreenShell>
        );
      case "location":
        return (
          <ScreenShell>
            <Header title="" onBack={back} />
            <Progress step={3} total={3} />
            <div className="location-hero">
              <div className="map-art">
                <span className="map-pin p1" />
                <span className="map-pin p2" />
                <span className="map-pin p3" />
                <div className="you-pin">
                  <Icon name="pin" />
                </div>
              </div>
              <span className="eyebrow">AROUND YOU</span>
              <h1>Good things are closer than you think.</h1>
              <p>
                Location helps us surface communities and events in your neighbourhood. You’re
                always in control.
              </p>
              <Button onClick={() => go("home")}>
                <Icon name="pin" size={18} /> Enable location
              </Button>
              <Button variant="secondary" onClick={() => go("home")}>
                Select city manually
              </Button>
              <button className="text-link" onClick={() => go("home")}>
                Not now
              </button>
            </div>
          </ScreenShell>
        );
      case "home":
        return (
          <ScreenShell nav>
            <div className="home-top">
              <div>
                <small>Good morning, Maya</small>
                <h1>Find your people.</h1>
              </div>
              <button className="avatar" onClick={() => go("profile")}>
                <img src={photos.friends} alt="" />
              </button>
              <button className="bell" onClick={() => go("notifications")}>
                <Icon name="bell" />
                <i />
              </button>
            </div>
            <div className="page home-page">
              <button className="search" onClick={() => go("discover")}>
                <Icon name="search" />
                <span>Looking for something?</span>
                <kbd>⌘ K</kbd>
              </button>
              <div className="promo">
                <div>
                  <span>HOST ON TRUHIVEE</span>
                  <h2>Got something to bring people together?</h2>
                  <button onClick={() => go("create")}>
                    Explore hosting <Icon name="arrow" size={16} />
                  </button>
                </div>
                <div className="promo-orbits">
                  <i />
                  <b>
                    <Icon name="spark" size={28} />
                  </b>
                </div>
              </div>
              <SectionTitle onClick={() => go("events")}>Your next little adventure</SectionTitle>
              <div className="card-scroll">
                {eventData.slice(0, 3).map((e) => (
                  <EventCard key={e.title} event={e} onClick={() => go("eventDetail")} />
                ))}
              </div>
              <SectionTitle onClick={() => go("communities")}>Your kind of people</SectionTitle>
              <div className="stack">
                {communityData.slice(0, 2).map((c) => (
                  <CommunityCard
                    key={c.title}
                    item={c}
                    joined={joined}
                    onJoin={() => setJoined(true)}
                    onOpen={() => go("communityDetail")}
                  />
                ))}
              </div>
              <section className="brewing">
                <div className="brew-icon">
                  <span />
                  <span />
                  <span />
                </div>
                <div>
                  <small>A LITTLE SOMETHING IS BREWING...</small>
                  <h3>Group plans are coming to Truhivee</h3>
                  <p>Turn “we should do this” into a plan everyone can join.</p>
                </div>
              </section>
            </div>
          </ScreenShell>
        );
      case "discover":
        return (
          <ScreenShell nav>
            <Header
              title="Discover"
              action={
                <button className="icon-btn" onClick={() => notify("Filters opened")}>
                  <Icon name="filter" />
                </button>
              }
            />
            <div className="page discover-page">
              <h1>
                Explore what’s
                <br />
                out there.
              </h1>
              <button className="search">
                <Icon name="search" />
                <span>Search events & communities</span>
              </button>
              <SectionTitle onClick={() => go("events")}>Trending events</SectionTitle>
              <div className="card-scroll">
                {eventData.map((e) => (
                  <EventCard key={e.title} event={e} onClick={() => go("eventDetail")} />
                ))}
              </div>
              <SectionTitle>Explore by interest</SectionTitle>
              <div className="category-scroll">
                {[
                  "All",
                  "Music",
                  "Art",
                  "Fitness",
                  "Sports",
                  "Travel",
                  "Food",
                  "Photography",
                  "Dance",
                  "Wellness",
                  "Reading",
                  "Technology",
                ].map((c, i) => (
                  <button
                    key={c}
                    className={i === 0 ? "selected" : ""}
                    onClick={() => notify(`${c} selected`)}
                  >
                    <img src={categoryImages[i % categoryImages.length]} alt="" />
                    <span>{c}</span>
                  </button>
                ))}
              </div>
              <SectionTitle onClick={() => go("events")}>Events near you</SectionTitle>
              <div className="stack">
                {eventData.slice(1, 4).map((e) => (
                  <EventCard key={e.title} wide event={e} onClick={() => go("eventDetail")} />
                ))}
              </div>
              <SectionTitle onClick={() => go("communities")}>Communities near you</SectionTitle>
              <div className="stack">
                {communityData.map((c) => (
                  <CommunityCard
                    key={c.title}
                    item={c}
                    joined={joined}
                    onJoin={() => setJoined(true)}
                    onOpen={() => go("communityDetail")}
                  />
                ))}
              </div>
            </div>
          </ScreenShell>
        );
      case "events":
        return (
          <ScreenShell>
            <Header
              title="Discover events"
              onBack={back}
              action={
                <button className="icon-btn">
                  <Icon name="filter" />
                </button>
              }
            />
            <div className="page">
              <button className="search">
                <Icon name="search" />
                <span>Search experiences</span>
              </button>
              <div className="chips">
                {["All", "This weekend", "Near me", "Free", "Paid"].map((x, i) => (
                  <button className={i === 0 ? "active" : ""} key={x}>
                    {x}
                  </button>
                ))}
              </div>
              <div className="result-count">
                <b>24 experiences</b>
                <span>Curated for you</span>
              </div>
              <div className="stack">
                {eventData.map((e) => (
                  <EventCard wide key={e.title} event={e} onClick={() => go("eventDetail")} />
                ))}
              </div>
              <div className="empty-state mini">
                <Icon name="calendar" />
                <b>No more plans nearby</b>
                <p>Try another date or broaden your location.</p>
              </div>
            </div>
          </ScreenShell>
        );
      case "communities":
        return (
          <ScreenShell>
            <Header
              title="Find communities"
              onBack={back}
              action={
                <button className="icon-btn">
                  <Icon name="filter" />
                </button>
              }
            />
            <div className="page">
              <button className="search">
                <Icon name="search" />
                <span>Search public communities</span>
              </button>
              <div className="chips">
                {["All", "Art", "Wellness", "Music", "Near me"].map((x, i) => (
                  <button className={i === 0 ? "active" : ""} key={x}>
                    {x}
                  </button>
                ))}
              </div>
              <div className="stack roomy">
                {communityData.concat(communityData.slice(0, 1)).map((c, i) => (
                  <CommunityCard
                    key={i}
                    item={c}
                    joined={joined}
                    onJoin={() => setJoined(true)}
                    onOpen={() => go("communityDetail")}
                  />
                ))}
              </div>
            </div>
          </ScreenShell>
        );
      case "eventDetail":
        return (
          <ScreenShell className="detail-screen">
            <div className="detail-hero">
              <img src={eventData[0].image} alt="" />
              <div className="detail-controls">
                <button onClick={back}>
                  <Icon name="back" />
                </button>
                <div>
                  <button>
                    <Icon name="share" />
                  </button>
                  <button>
                    <Icon name="heart" />
                  </button>
                </div>
              </div>
            </div>
            <div className="detail-sheet">
              <span className="category-tag">ART & CREATIVITY</span>
              <h1>Clay & Conversations</h1>
              <p className="host-line">
                <img src={photos.friends} alt="" /> Hosted by <b>Make Something</b>
              </p>
              <div className="detail-facts">
                <div>
                  <Icon name="calendar" />
                  <span>
                    <b>Saturday, 24 May</b>
                    <small>4:00 PM – 6:30 PM</small>
                  </span>
                </div>
                <div>
                  <Icon name="pin" />
                  <span>
                    <b>The Studio, Indiranagar</b>
                    <small>12th Main Road, Bengaluru</small>
                  </span>
                </div>
              </div>
              <section>
                <h3>About this experience</h3>
                <p>
                  Slow down, get your hands messy and meet kind people over clay. No experience
                  needed—just bring your curiosity.
                </p>
              </section>
              <section>
                <h3>What’s included</h3>
                <ul className="tick-list">
                  <li>All materials and firing</li>
                  <li>Guided hand-building session</li>
                  <li>Tea, snacks and good conversation</li>
                </ul>
              </section>
              <div className="capacity">
                <span>
                  <Icon name="users" /> 7 seats left
                </span>
                <i>
                  <b style={{ width: "72%" }} />
                </i>
              </div>
              <div className="detail-action">
                <div>
                  <small>From</small>
                  <b>₹850</b>
                </div>
                <Button onClick={() => go("registration")}>
                  {registered ? "View ticket" : "Register"}
                </Button>
              </div>
            </div>
          </ScreenShell>
        );
      case "registration":
        return (
          <FormScreen
            title="You’re almost in"
            subtitle="Review your details before reserving a seat."
            step={1}
            total={2}
            back={back}
            next={() => go("registrationQuestions")}
            fields={[
              { label: "Full name", placeholder: "Maya Rao" },
              { label: "Email", placeholder: "maya@example.com" },
              { label: "Phone number", placeholder: "+91 98765 43210" },
            ]}
          >
            <div className="mini-event">
              <img src={eventData[0].image} alt="" />
              <div>
                <b>Clay & Conversations</b>
                <small>Sat, 24 May · 4:00 PM</small>
              </div>
              <strong>₹850</strong>
            </div>
          </FormScreen>
        );
      case "registrationQuestions":
        return (
          <FormScreen
            title="A little about you"
            subtitle="The host would love to know a few things."
            step={2}
            total={2}
            back={back}
            next={() => {
              setRegistered(true);
              go("registered");
            }}
            nextLabel="Confirm registration"
            fields={[
              {
                label: "What brings you to this experience?",
                placeholder: "Share a little...",
                area: true,
              },
              {
                label: "Any accessibility or dietary needs? (Optional)",
                placeholder: "Let the host know",
                area: true,
              },
            ]}
          >
            <label className="check-row">
              <input type="checkbox" defaultChecked />
              <i>
                <Icon name="check" size={13} />
              </i>
              <span>I agree to the event and cancellation terms</span>
            </label>
          </FormScreen>
        );
      case "registered":
        return (
          <ScreenShell className="success-screen">
            <div className="confetti c1" />
            <div className="confetti c2" />
            <div className="confetti c3" />
            <div className="success-check">
              <Icon name="check" size={38} />
            </div>
            <span className="eyebrow">YOU’RE GOING</span>
            <h1>See you there, Maya!</h1>
            <p>Your spot at Clay & Conversations is confirmed.</p>
            <div className="ticket-stub">
              <img src={eventData[0].image} alt="" />
              <div>
                <small>24 MAY · 4:00 PM</small>
                <h3>Clay & Conversations</h3>
                <p>The Studio, Indiranagar</p>
                <div className="barcode">|||| ||| || |||| | |||</div>
              </div>
            </div>
            <Button onClick={() => go("tickets")}>View my ticket</Button>
            <Button variant="ghost" onClick={() => go("home")}>
              Back to home
            </Button>
          </ScreenShell>
        );
      case "create":
        return (
          <ScreenShell className="create-screen">
            <div className="create-head">
              <button onClick={back}>
                <Icon name="plus" />
              </button>
              <span>CREATE ON TRUHIVEE</span>
              <h1>
                What do you want
                <br />
                to bring to life?
              </h1>
              <p>Start something worth showing up for.</p>
            </div>
            <div className="create-options">
              <button onClick={() => (hostApproved ? go("eventBasic") : go("eventApplication"))}>
                <div className="option-icon yellow">
                  <Icon name="calendar" />
                </div>
                <span>
                  <small>HOST AN EVENT</small>
                  <h2>Bring people together through an experience.</h2>
                  <p>Plan workshops, meetups, walks, gigs and more.</p>
                </span>
                <Icon name="arrow" />
              </button>
              <button onClick={() => go("communityIntro")}>
                <div className="option-icon mint">
                  <Icon name="users" />
                </div>
                <span>
                  <small>HOST A COMMUNITY</small>
                  <h2>Create a space around a shared interest.</h2>
                  <p>Grow a lasting circle and host together.</p>
                </span>
                <Icon name="arrow" />
              </button>
            </div>
          </ScreenShell>
        );
      case "eventApplication":
        return (
          <FormScreen
            title="Tell us about you"
            subtitle="We review first-time hosts to keep every experience thoughtful and safe."
            step={1}
            total={3}
            back={back}
            next={() => go("eventApplicationReview")}
            fields={[
              { label: "Full name", placeholder: "Maya Rao" },
              { label: "Short bio", placeholder: "Tell us about yourself", area: true },
              { label: "Email address", placeholder: "maya@example.com" },
              { label: "Phone number", placeholder: "+91" },
              { label: "Hosting interests", placeholder: "Art, wellness, music..." },
              {
                label: "Previous hosting experience",
                placeholder: "What have you hosted before?",
                area: true,
              },
              { label: "Social media links", placeholder: "Instagram, LinkedIn or website" },
              { label: "Why Truhivee?", placeholder: "What would you love to create?", area: true },
              { label: "Portfolio or supporting links", placeholder: "Optional" },
            ]}
          />
        );
      case "eventApplicationReview":
        return (
          <ScreenShell>
            <Header title="Review application" onBack={back} />
            <div className="page review-page">
              <Progress step={3} total={3} />
              <h1>Everything look right?</h1>
              <p className="lead">You can still edit anything before submitting.</p>
              <ReviewBlock
                title="Applicant information"
                edit={() => go("eventApplication")}
                rows={[
                  ["Name", "Maya Rao"],
                  ["Email", "maya@example.com"],
                  ["Phone", "+91 98765 43210"],
                  ["Bio", "Designer, maker and community enthusiast."],
                ]}
              />
              <ReviewBlock
                title="Hosting information"
                edit={() => go("eventApplication")}
                rows={[
                  ["Interests", "Art, slow living, workshops"],
                  ["Experience", "Hosted 6 independent creative circles"],
                  ["Why Truhivee", "To create low-pressure spaces for making and meeting."],
                ]}
              />
              <Button onClick={() => go("eventApplicationStatus")}>Submit application</Button>
            </div>
          </ScreenShell>
        );
      case "eventApplicationStatus":
        return (
          <StatusView
            type={eventStatus}
            subject="event"
            back={back}
            next={() => {
              if (eventStatus !== "approved") {
                setHostApproved(true);
                setEventStatus("approved");
                notify("Application approved for prototype");
              } else go("eventBasic");
            }}
            setType={(status) => {
              setEventStatus(status);
              setHostApproved(status === "approved");
            }}
          />
        );
      case "eventBasic":
        return (
          <FormScreen
            title="Start with the story"
            subtitle="Give people a reason to pause and lean in."
            step={1}
            total={5}
            back={back}
            next={() => go("eventSchedule")}
            fields={[
              { label: "Event title", placeholder: "Something memorable" },
              {
                label: "Event description",
                placeholder: "What will happen, and who is it for?",
                area: true,
              },
            ]}
          >
            <SelectField label="Event category">Art & Creativity</SelectField>
            <button className="cover-upload">
              <Icon name="camera" />
              <b>Add event cover</b>
              <small>Landscape image · 1600 × 900 recommended</small>
            </button>
            <SelectField label="Event type">Host-led event</SelectField>
            <div className="info-box">
              Host-led events collect payments independently. Truhivee-led events collect through
              Truhivee; collaborative events use an agreed split.
            </div>
          </FormScreen>
        );
      case "eventSchedule":
        return (
          <FormScreen
            title="Pick a moment"
            subtitle="When should everyone show up?"
            step={2}
            total={5}
            back={back}
            next={() => go("eventLocation")}
            fields={[
              { label: "Event date", placeholder: "24 May 2025", type: "date" },
              { label: "Start time", placeholder: "4:00 PM", type: "time" },
              { label: "End time", placeholder: "6:30 PM", type: "time" },
            ]}
          >
            <label className="toggle-row">
              <span>
                <b>Recurring event</b>
                <small>Repeat on a regular schedule</small>
              </span>
              <input type="checkbox" />
            </label>
          </FormScreen>
        );
      case "eventLocation":
        return (
          <FormScreen
            title="Where’s it happening?"
            subtitle="Help people find their way."
            step={3}
            total={5}
            back={back}
            next={() => go("eventTickets")}
            fields={[
              { label: "Venue name", placeholder: "The Studio" },
              { label: "Full address", placeholder: "12th Main Road" },
              { label: "City", placeholder: "Bengaluru" },
            ]}
          >
            <div className="segmented">
              <button className="active">
                <Icon name="pin" /> Offline
              </button>
              <button>
                <Icon name="globe" /> Online
              </button>
            </div>
            <div className="map-preview">
              <div className="you-pin">
                <Icon name="pin" />
              </div>
              <span>Indiranagar, Bengaluru</span>
            </div>
          </FormScreen>
        );
      case "eventTickets":
        return (
          <FormScreen
            title="Tickets & capacity"
            subtitle="Set the shape and size of your gathering."
            step={4}
            total={5}
            back={back}
            next={() => go("eventQuestions")}
            fields={[
              { label: "Ticket price", placeholder: "₹ 850" },
              { label: "Maximum capacity", placeholder: "20" },
              { label: "Registration closes", placeholder: "2 hours before event" },
              { label: "UPI / collection details", placeholder: "Host-managed payment note" },
            ]}
          >
            <div className="segmented">
              <button>Free</button>
              <button className="active">Paid</button>
            </div>
            <div className="info-box">
              This host-led event collects payment independently. Truhivee does not process or
              settle this payment.
            </div>
          </FormScreen>
        );
      case "eventQuestions":
        return (
          <ScreenShell>
            <Header title="" onBack={back} />
            <Progress step={5} total={5} />
            <div className="page form-page">
              <span className="eyebrow">REGISTRATION FORM</span>
              <h1>Know your attendees</h1>
              <p className="lead">Add questions that help you host well.</p>
              <div className="question-builder">
                <div>
                  <span>Question 1</span>
                  <button>
                    <Icon name="more" />
                  </button>
                </div>
                <Field label="Question" placeholder="What brings you to this event?" />
                <div className="toggle-row">
                  <span>
                    <b>Required</b>
                    <small>Attendees must answer</small>
                  </span>
                  <input type="checkbox" defaultChecked />
                </div>
              </div>
              <button className="add-row">
                <Icon name="plus" /> Add another question
              </button>
              <div className="sticky-action">
                <Button onClick={() => go("eventPreview")}>Preview event</Button>
              </div>
            </div>
          </ScreenShell>
        );
      case "eventPreview":
        return (
          <ScreenShell>
            <Header
              title="Attendee preview"
              onBack={back}
              action={
                <button className="edit-link" onClick={() => go("eventBasic")}>
                  Edit
                </button>
              }
            />
            <div className="preview-banner">This is how your event will appear</div>
            <div className="preview-phone">
              <div className="detail-hero small">
                <img src={eventData[0].image} alt="" />
              </div>
              <div className="preview-copy">
                <span className="category-tag">ART & CREATIVITY</span>
                <h1>Clay & Conversations</h1>
                <p>Slow down, get your hands messy and meet kind people over clay.</p>
                <div className="detail-facts">
                  <div>
                    <Icon name="calendar" />
                    <span>
                      <b>Saturday, 24 May</b>
                      <small>4:00 PM – 6:30 PM</small>
                    </span>
                  </div>
                  <div>
                    <Icon name="pin" />
                    <span>
                      <b>The Studio, Indiranagar</b>
                      <small>Bengaluru</small>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="page">
              <Button onClick={() => go("eventPublish")}>Looks good, continue</Button>
            </div>
          </ScreenShell>
        );
      case "eventPublish":
        return (
          <ScreenShell className="publish-page">
            <Header title="Publish event" onBack={back} />
            <div className="publish-hero">
              <div className="status-orb approved">
                <Icon name="spark" size={34} />
              </div>
              <span className="eyebrow">READY WHEN YOU ARE</span>
              <h1>Your experience is ready to meet the world.</h1>
              <p>Review complete. You can save a draft or publish now.</p>
            </div>
            <ReviewBlock
              title="Clay & Conversations"
              rows={[
                ["Date", "Sat, 24 May · 4:00 PM"],
                ["Location", "The Studio, Indiranagar"],
                ["Ticket", "₹850 · 20 seats"],
                ["Payment", "Collected independently by host"],
              ]}
            />
            <div className="page publish-actions">
              <Button variant="secondary" onClick={() => notify("Draft saved")}>
                Save draft
              </Button>
              <Button
                onClick={() => {
                  notify("Event published");
                  window.setTimeout(() => go("eventManagement"), 800);
                }}
              >
                Publish event
              </Button>
            </div>
          </ScreenShell>
        );
      case "eventManagement":
        return (
          <ScreenShell>
            <Header
              title="Event management"
              onBack={() => go("profile")}
              action={
                <button className="icon-btn">
                  <Icon name="more" />
                </button>
              }
            />
            <div className="page">
              <div className="manager-hero">
                <img src={eventData[0].image} alt="" />
                <div>
                  <span className="status-pill approved">Published</span>
                  <h2>Clay & Conversations</h2>
                  <p>Sat, 24 May · 4:00 PM</p>
                </div>
              </div>
              <div className="stats">
                <div>
                  <b>13</b>
                  <small>Registered</small>
                </div>
                <div>
                  <b>7</b>
                  <small>Seats left</small>
                </div>
                <div>
                  <b>65%</b>
                  <small>Filled</small>
                </div>
              </div>
              <div className="menu-list">
                <button>
                  <Icon name="users" />
                  <span>
                    <b>Registrations & attendees</b>
                    <small>View 13 responses</small>
                  </span>
                  <Icon name="chevron" />
                </button>
                <button onClick={() => go("eventBasic")}>
                  <Icon name="edit" />
                  <span>
                    <b>Edit event details</b>
                    <small>Update information</small>
                  </span>
                  <Icon name="chevron" />
                </button>
                <button>
                  <Icon name="message" />
                  <span>
                    <b>Message attendees</b>
                    <small>Send an update</small>
                  </span>
                  <Icon name="chevron" />
                </button>
                <button>
                  <Icon name="settings" />
                  <span>
                    <b>Event settings</b>
                    <small>Visibility and cancellation</small>
                  </span>
                  <Icon name="chevron" />
                </button>
              </div>
              <SectionTitle>Upcoming events</SectionTitle>
              <EventCard wide event={eventData[2]} onClick={() => go("eventDetail")} />
            </div>
          </ScreenShell>
        );
      case "communityIntro":
        return (
          <ScreenShell className="community-intro">
            <div className="intro-image">
              <img src={photos.gathering} alt="" />
              <button onClick={back}>
                <Icon name="back" />
              </button>
            </div>
            <div className="page">
              <span className="eyebrow">HOST A COMMUNITY</span>
              <h1>Make room for something meaningful.</h1>
              <p className="lead">
                Build a welcoming home for people who share an interest, curiosity or way of seeing
                the world.
              </p>
              <div className="benefit-list">
                <div>
                  <i>01</i>
                  <span>
                    <b>Shape the culture</b>
                    <small>Create the tone, guidelines and rhythm.</small>
                  </span>
                </div>
                <div>
                  <i>02</i>
                  <span>
                    <b>Bring people together</b>
                    <small>Start discussions and host repeat events.</small>
                  </span>
                </div>
                <div>
                  <i>03</i>
                  <span>
                    <b>Grow with support</b>
                    <small>Truhivee helps you build thoughtfully.</small>
                  </span>
                </div>
              </div>
              <Button onClick={() => go("communityApplicant")}>Start application</Button>
            </div>
          </ScreenShell>
        );
      case "communityApplicant":
        return (
          <FormScreen
            title="First, about you"
            subtitle="Tell us who will be caring for this community."
            step={1}
            total={4}
            back={back}
            next={() => go("communityConcept")}
            fields={[
              { label: "Full name", placeholder: "Maya Rao" },
              { label: "Short bio", placeholder: "Tell us about yourself", area: true },
              { label: "Contact email", placeholder: "maya@example.com" },
              { label: "Phone number", placeholder: "+91" },
            ]}
          />
        );
      case "communityConcept":
        return (
          <FormScreen
            title="The community idea"
            subtitle="What kind of space do you want to build?"
            step={2}
            total={4}
            back={back}
            next={() => go("communityExperience")}
            fields={[
              { label: "Proposed community name", placeholder: "The Slow Sunday Club" },
              {
                label: "Proposed description",
                placeholder: "A clear, warm introduction",
                area: true,
              },
              {
                label: "Community concept",
                placeholder: "What will members do and feel here?",
                area: true,
              },
            ]}
          >
            <SelectField label="Genre / category">Wellness & Slow living</SelectField>
          </FormScreen>
        );
      case "communityExperience":
        return (
          <FormScreen
            title="Your hosting story"
            subtitle="Experience can be formal or completely self-made."
            step={3}
            total={4}
            back={back}
            next={() => go("communityReview")}
            fields={[
              {
                label: "Previous experience",
                placeholder: "Communities, groups or gatherings",
                area: true,
              },
              { label: "Social media links", placeholder: "Instagram, LinkedIn or website" },
              {
                label: "Why this community?",
                placeholder: "Why do you want to build it?",
                area: true,
              },
              {
                label: "Supporting information",
                placeholder: "Links, press or examples (optional)",
                area: true,
              },
            ]}
          />
        );
      case "communityReview":
        return (
          <ScreenShell>
            <Header title="Review application" onBack={back} />
            <div className="page review-page">
              <Progress step={4} total={4} />
              <h1>Your community, in summary.</h1>
              <ReviewBlock
                title="Applicant"
                edit={() => go("communityApplicant")}
                rows={[
                  ["Name", "Maya Rao"],
                  ["Email", "maya@example.com"],
                  ["Phone", "+91 98765 43210"],
                ]}
              />
              <ReviewBlock
                title="Concept"
                edit={() => go("communityConcept")}
                rows={[
                  ["Name", "The Slow Sunday Club"],
                  ["Genre", "Wellness & slow living"],
                  ["Concept", "A calm, local circle for unhurried plans."],
                ]}
              />
              <ReviewBlock
                title="Experience"
                edit={() => go("communityExperience")}
                rows={[
                  ["Previous hosting", "Six independent creative circles"],
                  ["Motivation", "To make belonging feel easier."],
                ]}
              />
              <Button onClick={() => go("communitySubmitted")}>Submit application</Button>
            </div>
          </ScreenShell>
        );
      case "communitySubmitted":
        return (
          <ScreenShell className="success-screen">
            <div className="success-check">
              <Icon name="check" size={38} />
            </div>
            <span className="eyebrow">APPLICATION SENT</span>
            <h1>It’s in good hands.</h1>
            <p>Our community team will review your idea and get back to you in 3–5 working days.</p>
            <Button onClick={() => go("communityStatus")}>Track application</Button>
            <Button variant="ghost" onClick={() => go("home")}>
              Back to home
            </Button>
          </ScreenShell>
        );
      case "communityStatus":
        return (
          <StatusView
            type={communityStatus}
            subject="community"
            back={back}
            next={() => {
              if (communityStatus !== "approved") {
                setCommunityApproved(true);
                setCommunityStatus("approved");
                notify("Community approved for prototype");
              } else go("hive");
            }}
            setType={(status) => {
              setCommunityStatus(status);
              setCommunityApproved(status === "approved");
            }}
          />
        );
      case "hive":
        return (
          <ScreenShell nav>
            <Header
              title="Your Hive"
              action={
                <button className="icon-btn" onClick={() => go("communities")}>
                  <Icon name="plus" />
                </button>
              }
            />
            <div className="page hive-page">
              {communityApproved && (
                <div className="tabs">
                  <button
                    className={hiveTab === "created" ? "active" : ""}
                    onClick={() => setHiveTab("created")}
                  >
                    Created communities
                  </button>
                  <button
                    className={hiveTab === "joined" ? "active" : ""}
                    onClick={() => setHiveTab("joined")}
                  >
                    Joined communities
                  </button>
                </div>
              )}
              {communityApproved && hiveTab === "created" ? (
                <>
                  <div className="hive-intro">
                    <span>HOST SPACE</span>
                    <h2>What will you make happen next?</h2>
                  </div>
                  <article className="owned-card">
                    <img src={photos.friends} alt="" />
                    <div>
                      <span
                        className={`status-pill ${communityPublished ? "approved" : "pending"}`}
                      >
                        {communityPublished ? "Published" : "Setup pending"}
                      </span>
                      <h3>The Slow Sunday Club</h3>
                      <p>
                        {communityPublished
                          ? "2.4k members · 3 upcoming events"
                          : "Complete your space to start welcoming members."}
                      </p>
                      <Button
                        onClick={() =>
                          go(communityPublished ? "communityManagement" : "communitySetup")
                        }
                      >
                        {communityPublished ? "Manage community" : "Continue setup"}
                      </Button>
                    </div>
                  </article>
                </>
              ) : joined ? (
                <>
                  <p className="hive-welcome">Spaces you’re part of, all in one place.</p>
                  {communityData.slice(0, 2).map((c) => (
                    <CommunityCard key={c.title} item={c} onOpen={() => go("discussions")} />
                  ))}
                </>
              ) : (
                <div className="empty-state">
                  <div className="empty-orbit">
                    <Icon name="users" size={30} />
                  </div>
                  <h2>Your hive is waiting</h2>
                  <p>Join a community and conversations, plans and new people will show up here.</p>
                  <Button onClick={() => go("communities")}>Explore communities</Button>
                </div>
              )}
            </div>
          </ScreenShell>
        );
      case "communitySetup":
        return (
          <FormScreen
            title="Build your community home"
            subtitle="You can save a draft and come back anytime."
            step={1}
            total={2}
            back={back}
            next={() => go("communityPreview")}
            fields={[
              { label: "Community name", placeholder: "The Slow Sunday Club" },
              {
                label: "Community about",
                placeholder: "Tell future members what this space is for",
                area: true,
              },
              { label: "Social media links", placeholder: "Instagram, website or newsletter" },
              {
                label: "Community guidelines (Optional)",
                placeholder: "How will people treat each other here?",
                area: true,
              },
            ]}
          >
            <div className="upload-pair">
              <button>
                <Icon name="camera" />
                <b>Cover image</b>
                <small>1600 × 900</small>
              </button>
              <button>
                <Icon name="user" />
                <b>Profile image</b>
                <small>Optional</small>
              </button>
            </div>
            <SelectField label="Genre / category">Wellness & slow living</SelectField>
            <div className="segmented">
              <button className="active">
                <Icon name="globe" /> Public
              </button>
              <button>
                <Icon name="lock" /> Private
              </button>
            </div>
            <Button variant="secondary" onClick={() => notify("Community draft saved")}>
              Save draft
            </Button>
          </FormScreen>
        );
      case "communityPreview":
        return (
          <ScreenShell>
            <Header
              title="Community preview"
              onBack={back}
              action={
                <button className="edit-link" onClick={() => go("communitySetup")}>
                  Edit
                </button>
              }
            />
            <div className="community-profile">
              <div className="community-cover">
                <img src={photos.friends} alt="" />
              </div>
              <img className="community-avatar" src={photos.outdoors} alt="" />
              <div className="community-head">
                <span className="category-tag">WELLNESS · PUBLIC</span>
                <h1>The Slow Sunday Club</h1>
                <p>
                  <Icon name="users" size={15} /> 0 members
                </p>
                <Button variant="secondary">Join community</Button>
              </div>
              <section>
                <h3>About</h3>
                <p>A calm, local circle for unhurried plans, mindful mornings and good company.</p>
              </section>
              <section>
                <h3>Community guidelines</h3>
                <ol>
                  <li>Come as you are.</li>
                  <li>Choose curiosity over judgement.</li>
                  <li>Respect everyone’s pace.</li>
                </ol>
              </section>
              <section>
                <h3>Find us online</h3>
                <button className="social-link">
                  <Icon name="globe" /> @slowsundayclub
                </button>
              </section>
            </div>
            <div className="page">
              <Button onClick={() => go("communityPublish")}>Continue to publish</Button>
            </div>
          </ScreenShell>
        );
      case "communityPublish":
        return (
          <ScreenShell className="success-screen">
            <div className="success-check">
              <Icon name="spark" size={38} />
            </div>
            <span className="eyebrow">READY TO GROW</span>
            <h1>Open the doors to your community.</h1>
            <p>Once published, people can discover and join The Slow Sunday Club.</p>
            <Button
              onClick={() => {
                setCommunityPublished(true);
                notify("Community published");
                window.setTimeout(() => go("communityManagement"), 700);
              }}
            >
              Publish community
            </Button>
            <Button variant="secondary" onClick={() => notify("Draft saved")}>
              Save as draft
            </Button>
          </ScreenShell>
        );
      case "communityManagement":
        return (
          <ScreenShell>
            <div className="manager-cover">
              <img src={photos.friends} alt="" />
              <button onClick={back}>
                <Icon name="back" />
              </button>
              <button>
                <Icon name="more" />
              </button>
            </div>
            <div className="page manager-community">
              <span className="status-pill approved">Published</span>
              <h1>The Slow Sunday Club</h1>
              <p>2.4k members · Wellness & slow living</p>
              <div className="stats">
                <div>
                  <b>2.4k</b>
                  <small>Members</small>
                </div>
                <div>
                  <b>18</b>
                  <small>Posts</small>
                </div>
                <div>
                  <b>3</b>
                  <small>Events</small>
                </div>
              </div>
              <div className="quick-grid">
                <button onClick={() => go("discussions")}>
                  <Icon name="message" />
                  <b>Discussions</b>
                </button>
                <button>
                  <Icon name="users" />
                  <b>Members</b>
                </button>
                <button onClick={() => go("eventBasic")}>
                  <Icon name="calendar" />
                  <b>Create event</b>
                </button>
                <button onClick={() => go("communitySetup")}>
                  <Icon name="edit" />
                  <b>Edit community</b>
                </button>
              </div>
              <SectionTitle>Upcoming events</SectionTitle>
              <EventCard wide event={eventData[1]} onClick={() => go("eventDetail")} />
              <div className="menu-list">
                <button>
                  <Icon name="settings" />
                  <span>
                    <b>Community settings</b>
                    <small>Visibility and host roles</small>
                  </span>
                  <Icon name="chevron" />
                </button>
              </div>
            </div>
          </ScreenShell>
        );
      case "communityDetail":
        return (
          <ScreenShell>
            <div className="community-profile">
              <div className="community-cover">
                <img src={communityData[0].image} alt="" />
                <button className="cover-back" onClick={back}>
                  <Icon name="back" />
                </button>
                <button className="cover-share">
                  <Icon name="share" />
                </button>
              </div>
              <img className="community-avatar" src={photos.outdoors} alt="" />
              <div className="community-head">
                <span className="category-tag">WELLNESS · PUBLIC</span>
                <h1>The Slow Sunday Club</h1>
                <p>
                  <Icon name="users" size={15} /> 2.4k members
                </p>
                <Button
                  variant={joined ? "secondary" : "primary"}
                  onClick={() => {
                    setJoined(true);
                    notify("Welcome to the community");
                  }}
                >
                  {joined ? "Joined" : "Join community"}
                </Button>
              </div>
              <section>
                <h3>About</h3>
                <p>
                  Unhurried mornings, mindful plans and good company. A place to make weekends feel
                  more like yours.
                </p>
              </section>
              <section>
                <h3>Community guidelines</h3>
                <ol>
                  <li>Come as you are.</li>
                  <li>Choose curiosity over judgement.</li>
                  <li>No unsolicited promotion.</li>
                </ol>
              </section>
              <section>
                <h3>Find us online</h3>
                <button className="social-link">
                  <Icon name="globe" /> @slowsundayclub
                </button>
              </section>
              {joined && (
                <div className="page">
                  <Button onClick={() => go("discussions")}>Open in Hive</Button>
                </div>
              )}
            </div>
          </ScreenShell>
        );
      case "discussions":
        return (
          <ScreenShell>
            <Header
              title="Slow Sunday Club"
              onBack={back}
              action={
                <button className="icon-btn">
                  <Icon name="more" />
                </button>
              }
            />
            <div className="discussion-cover">
              <div>
                <span>COMMUNITY DISCUSSIONS</span>
                <h1>Good morning, hive.</h1>
              </div>
            </div>
            <div className="page discussion-page">
              <button className="create-post" onClick={() => setCreatedPost(true)}>
                <img src={photos.friends} alt="" />
                <span>Share something with your hive...</span>
                <Icon name="camera" />
              </button>
              {createdPost && (
                <article className="post new">
                  <header>
                    <img src={photos.friends} alt="" />
                    <span>
                      <b>Maya Rao</b>
                      <small>Just now</small>
                    </span>
                    <Icon name="more" />
                  </header>
                  <p>Excited for our next slow Sunday. Who’s bringing a book?</p>
                  <footer>
                    <button>
                      <Icon name="heart" size={18} /> 0
                    </button>
                    <button>
                      <Icon name="message" size={18} /> Comment
                    </button>
                  </footer>
                </article>
              )}
              <article className="post">
                <header>
                  <img src={photos.outdoors} alt="" />
                  <span>
                    <b>Anika Menon</b>
                    <small>2h · Bengaluru</small>
                  </span>
                  <Icon name="more" />
                </header>
                <p>
                  Found the loveliest shaded patch for this Sunday’s picnic. Bringing extra
                  mats—just bring yourself and something you’re reading.
                </p>
                <img className="post-image" src={photos.books} alt="" />
                <footer>
                  <button className="liked">
                    <Icon name="heart" size={18} /> 24
                  </button>
                  <button>
                    <Icon name="message" size={18} /> 8 comments
                  </button>
                </footer>
              </article>
              <article className="post">
                <header>
                  <img src={photos.gathering} alt="" />
                  <span>
                    <b>Rohan Kapoor</b>
                    <small>Yesterday</small>
                  </span>
                  <Icon name="more" />
                </header>
                <p>Would anyone be up for a no-phones morning walk next weekend?</p>
                <footer>
                  <button>
                    <Icon name="heart" size={18} /> 16
                  </button>
                  <button>
                    <Icon name="message" size={18} /> 12 comments
                  </button>
                </footer>
              </article>
            </div>
            <button className="fab" onClick={() => setCreatedPost(true)}>
              <Icon name="plus" />
            </button>
          </ScreenShell>
        );
      case "profile":
        return (
          <ScreenShell nav>
            <Header
              title="Profile"
              action={
                <button className="icon-btn" onClick={() => go("settings")}>
                  <Icon name="settings" />
                </button>
              }
            />
            <div className="page profile-page">
              <div className="profile-identity">
                <div className="profile-photo">
                  <img src={photos.friends} alt="" />
                  <i />
                </div>
                <h1>Maya Rao</h1>
                <p>
                  <Icon name="pin" size={14} /> Bengaluru
                </p>
                <span>
                  Designer, weekend potter and always looking for good people and slower plans.
                </span>
                <Button variant="secondary" onClick={() => go("editProfile")}>
                  <Icon name="edit" size={17} /> Edit profile
                </Button>
              </div>
              <div className="profile-stats">
                <button onClick={() => go("tickets")}>
                  <b>12</b>
                  <small>Events joined</small>
                </button>
                <button onClick={() => go("tickets")}>
                  <b>3</b>
                  <small>Upcoming</small>
                </button>
                <button onClick={() => go("tickets")}>
                  <b>9</b>
                  <small>Past</small>
                </button>
              </div>
              <SectionTitle>Coming up</SectionTitle>
              <EventCard wide event={eventData[0]} onClick={() => go("eventDetail")} />
              {hostApproved && (
                <>
                  <SectionTitle>Hosting</SectionTitle>
                  <button className="hosting-row" onClick={() => go("eventManagement")}>
                    <span>
                      <b>Clay & Conversations</b>
                      <small>13 registrations · Published</small>
                    </span>
                    <Icon name="chevron" />
                  </button>
                </>
              )}
            </div>
          </ScreenShell>
        );
      case "editProfile":
        return (
          <FormScreen
            title="Edit profile"
            subtitle="Keep it real, keep it you."
            back={back}
            next={() => {
              notify("Profile updated");
              back();
            }}
            nextLabel="Save changes"
            fields={[
              { label: "Name", placeholder: "Maya Rao" },
              { label: "Bio", placeholder: "A little about you", area: true },
              { label: "Location", placeholder: "Bengaluru" },
              { label: "Interests", placeholder: "Art, Music, Wellness" },
              { label: "Social links", placeholder: "Instagram or website" },
            ]}
          >
            <button className="avatar-upload">
              <img src={photos.friends} alt="" />
              <span>
                <Icon name="camera" />
                Change photo
              </span>
            </button>
          </FormScreen>
        );
      case "settings":
        return (
          <ScreenShell>
            <Header title="Settings" onBack={back} />
            <div className="page settings-page">
              <p className="menu-label">YOUR ACCOUNT</p>
              <div className="menu-list">
                <button onClick={() => go("account")}>
                  <Icon name="user" />
                  <span>
                    <b>Account information</b>
                    <small>Name, email and phone</small>
                  </span>
                  <Icon name="chevron" />
                </button>
                <button onClick={() => go("tickets")}>
                  <Icon name="ticket" />
                  <span>
                    <b>My tickets</b>
                    <small>Upcoming and past events</small>
                  </span>
                  <Icon name="chevron" />
                </button>
              </div>
              <p className="menu-label">ABOUT & SUPPORT</p>
              <div className="menu-list">
                <button onClick={() => go("about")}>
                  <Icon name="spark" />
                  <span>
                    <b>About Truhivee</b>
                  </span>
                  <Icon name="chevron" />
                </button>
                {["Privacy Policy", "Community Guidelines", "Terms & Conditions"].map((x) => (
                  <button key={x} onClick={() => go("legal")}>
                    <Icon name="globe" />
                    <span>
                      <b>{x}</b>
                    </span>
                    <Icon name="chevron" />
                  </button>
                ))}
                <button onClick={() => go("contact")}>
                  <Icon name="mail" />
                  <span>
                    <b>Contact us</b>
                  </span>
                  <Icon name="chevron" />
                </button>
              </div>
              <div className="danger-zone">
                <button onClick={() => setShowLogout(true)}>
                  <Icon name="arrow" /> Log out
                </button>
                <button onClick={() => go("deleteAccount")}>
                  <Icon name="user" /> Delete account
                </button>
              </div>
              <small className="version">Truhivee · Version 1.0.0</small>
            </div>
          </ScreenShell>
        );
      case "account":
        return (
          <ScreenShell>
            <Header
              title="Account information"
              onBack={back}
              action={<button className="edit-link">Edit</button>}
            />
            <div className="page">
              <div className="account-card">
                <div className="account-avatar">
                  <img src={photos.friends} alt="" />
                </div>
                <ReviewBlock
                  title="Personal details"
                  rows={[
                    ["Full name", "Maya Rao"],
                    ["Email address", "maya@example.com"],
                    ["Phone number", "+91 98765 43210"],
                  ]}
                />
              </div>
            </div>
          </ScreenShell>
        );
      case "tickets":
        return (
          <ScreenShell>
            <Header title="My tickets" onBack={back} />
            <div className="page">
              <div className="tabs">
                <button
                  className={ticketTab === "upcoming" ? "active" : ""}
                  onClick={() => setTicketTab("upcoming")}
                >
                  Upcoming
                </button>
                <button
                  className={ticketTab === "past" ? "active" : ""}
                  onClick={() => setTicketTab("past")}
                >
                  Past
                </button>
              </div>
              {ticketTab === "upcoming" ? (
                <div className="ticket-list">
                  <div className="ticket-card">
                    <img src={eventData[0].image} alt="" />
                    <div>
                      <span className="status-pill approved">Confirmed</span>
                      <h3>Clay & Conversations</h3>
                      <p>
                        <Icon name="calendar" size={14} /> Sat, 24 May · 4:00 PM
                      </p>
                      <p>
                        <Icon name="pin" size={14} /> The Studio, Indiranagar
                      </p>
                      <button onClick={() => go("eventDetail")}>
                        View ticket <Icon name="arrow" size={15} />
                      </button>
                    </div>
                  </div>
                  {registered && (
                    <div className="ticket-card">
                      <img src={eventData[2].image} alt="" />
                      <div>
                        <span className="status-pill approved">Confirmed</span>
                        <h3>Indie Under the Stars</h3>
                        <p>Fri, 30 May · 7:00 PM</p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="ticket-list">
                  <div className="ticket-card faded">
                    <img src={eventData[3].image} alt="" />
                    <div>
                      <span className="status-pill">Attended</span>
                      <h3>Creative Sunday Club</h3>
                      <p>Sun, 4 May · 11:00 AM</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScreenShell>
        );
      case "about":
        return (
          <ScreenShell className="about-screen">
            <Header title="About" onBack={back} />
            <div className="about-hero">
              <Logo />
              <h1>Belonging shouldn’t feel hard to find.</h1>
              <p>
                Truhivee brings people together around the interests, moments and places that make
                life feel richer.
              </p>
            </div>
            <div className="page">
              <section className="mission">
                <span>OUR MISSION</span>
                <h2>Make the world feel a little less disconnected.</h2>
                <p>
                  We’re building thoughtful tools for real-world community—where discovery leads to
                  showing up, and showing up can lead to belonging.
                </p>
              </section>
              <img className="about-image" src={photos.gathering} alt="" />
              <small className="version">Made with care · Version 1.0.0</small>
            </div>
          </ScreenShell>
        );
      case "contact":
        return (
          <FormScreen
            title="We’re here to help"
            subtitle="Tell us what’s going on and the Truhivee team will get back to you."
            back={back}
            next={() => {
              notify("Message sent");
              back();
            }}
            nextLabel="Send message"
            fields={[
              {
                label: "Support email",
                placeholder: "Provided by the Truhivee team",
                type: "email",
              },
              { label: "Subject", placeholder: "How can we help?" },
              { label: "Message", placeholder: "Share as much detail as you can", area: true },
            ]}
          />
        );
      case "deleteAccount":
        return (
          <ScreenShell className="status-screen">
            <Header title="Delete account" onBack={back} />
            <div className="status-body">
              <div className="status-orb rejected">
                <Icon name="user" size={32} />
              </div>
              <h1>Delete your account?</h1>
              <p>
                This permanently removes your profile, memberships, tickets and hosting history.
                This action cannot be undone.
              </p>
              <div className="warning-box">
                <b>Before you go</b>
                <p>
                  Upcoming registrations will be cancelled. Hosted events must be transferred or
                  cancelled first.
                </p>
              </div>
              <Button
                variant="danger"
                onClick={() => notify("Account deletion confirmation required")}
              >
                Yes, delete my account
              </Button>
              <Button variant="ghost" onClick={back}>
                Cancel
              </Button>
            </div>
          </ScreenShell>
        );
      case "notifications":
        return (
          <ScreenShell>
            <Header
              title="Notifications"
              onBack={back}
              action={<button className="edit-link">Mark all read</button>}
            />
            <div className="page notification-page">
              <p className="menu-label">TODAY</p>
              {[
                [
                  "calendar",
                  "Clay & Conversations is tomorrow",
                  "Your event starts at 4:00 PM. We’ll see you there.",
                  "12m",
                ],
                [
                  "check",
                  "Your host application was approved",
                  "You can now create and publish experiences.",
                  "1h",
                ],
                [
                  "message",
                  "Anika replied to your comment",
                  "“I’ll bring an extra mat for you!”",
                  "2h",
                ],
              ].map((n, i) => (
                <button className={`notification ${i < 2 ? "unread" : ""}`} key={n[1]}>
                  <i>
                    <Icon name={n[0] as IconName} />
                  </i>
                  <span>
                    <b>{n[1]}</b>
                    <p>{n[2]}</p>
                    <small>{n[3]}</small>
                  </span>
                </button>
              ))}
              <p className="menu-label">EARLIER</p>
              {[
                [
                  "users",
                  "Welcome to The Slow Sunday Club",
                  "You’re officially part of the hive.",
                  "Yesterday",
                ],
                ["ticket", "Registration confirmed", "Your ticket is ready in My Tickets.", "Mon"],
              ].map((n) => (
                <button className="notification" key={n[1]}>
                  <i>
                    <Icon name={n[0] as IconName} />
                  </i>
                  <span>
                    <b>{n[1]}</b>
                    <p>{n[2]}</p>
                    <small>{n[3]}</small>
                  </span>
                </button>
              ))}
            </div>
          </ScreenShell>
        );
      case "legal":
        return (
          <ScreenShell>
            <Header title="Truhivee policies" onBack={back} />
            <div className="page legal-page">
              <span className="eyebrow">LAST UPDATED · MAY 2025</span>
              <h1>Community comes with care.</h1>
              <p>These guidelines help make Truhivee welcoming, safe and useful for everyone.</p>
              <h3>Be kind and constructive</h3>
              <p>
                Treat people with dignity. Harassment, hate speech and targeted abuse have no place
                here.
              </p>
              <h3>Host responsibly</h3>
              <p>
                Share accurate information, communicate changes promptly and make accessibility a
                consideration.
              </p>
              <h3>Protect privacy</h3>
              <p>Don’t share another person’s private information or imagery without permission.</p>
              <h3>Show up honestly</h3>
              <p>Represent yourself, your community and your events truthfully.</p>
            </div>
          </ScreenShell>
        );
      default:
        return null;
    }
    // The screen state intentionally drives this complete prototype router.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    screen,
    onboard,
    joined,
    selectedInterests,
    hostApproved,
    communityApproved,
    eventStatus,
    communityStatus,
    communityPublished,
    registered,
    hiveTab,
    ticketTab,
    otp,
    authError,
    createdPost,
  ]);

  return (
    <div className="app-stage">
      <div className="device">
        {content}
        {isNav && <BottomNav current={screen} go={go} />}
        {toast && (
          <div className="toast">
            <Icon name="check" size={16} />
            {toast}
          </div>
        )}
        {showLogout && (
          <div className="modal-layer" onClick={() => setShowLogout(false)}>
            <div className="confirm-modal" onClick={(event) => event.stopPropagation()}>
              <div className="modal-icon">
                <Icon name="arrow" />
              </div>
              <h2>Log out of Truhivee?</h2>
              <p>
                You’ll need to sign in again to see your communities, tickets and hosting tools.
              </p>
              <Button
                onClick={() => {
                  setShowLogout(false);
                  setHistory([]);
                  setScreen("welcome");
                }}
              >
                Log out
              </Button>
              <Button variant="ghost" onClick={() => setShowLogout(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
      <div className="prototype-note">
        <Logo />
        <p>Interactive mobile prototype</p>
        <span>393 × 873 · Explore every flow in the app</span>
      </div>
    </div>
  );
}
